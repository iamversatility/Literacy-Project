﻿namespace Neo.Core
{
    public enum StateType : byte
    {
        Account = 0x40,
        Validator = 0x48
    }
}
