﻿namespace Neo.Implementations.Wallets.EntityFramework
{
    internal class Address
    {
        public byte[] ScriptHash { get; set; }
    }
}
