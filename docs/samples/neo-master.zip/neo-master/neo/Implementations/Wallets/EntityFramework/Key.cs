﻿namespace Neo.Implementations.Wallets.EntityFramework
{
    internal class Key
    {
        public string Name { get; set; }
        public byte[] Value { get; set; }
    }
}
