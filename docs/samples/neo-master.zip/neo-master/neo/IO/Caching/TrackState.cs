﻿namespace Neo.IO.Caching
{
    public enum TrackState : byte
    {
        None,
        Added,
        Changed,
        Deleted
    }
}
